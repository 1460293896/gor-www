<?php
$ix='gor';include('v.php');